document.getElementById("cta-button").addEventListener("click", () => {
  alert("登録ページへ移動します（デモ）");
});
