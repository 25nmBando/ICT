export interface MsgTest {
    name: string;
    age: number;
    gender: 'Male' | 'Female';
}
