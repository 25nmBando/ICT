import { AxiosStatic } from "axios";

declare global {
    const axios: AxiosStatic;
}

export {
    
};

