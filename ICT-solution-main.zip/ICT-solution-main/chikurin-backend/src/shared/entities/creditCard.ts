
import { ObjectId } from 'mongodb';

export interface creditCard {
    _id: ObjectId
}
