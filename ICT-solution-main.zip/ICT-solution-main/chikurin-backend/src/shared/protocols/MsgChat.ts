export interface MsgChat {
    content: string;
}
