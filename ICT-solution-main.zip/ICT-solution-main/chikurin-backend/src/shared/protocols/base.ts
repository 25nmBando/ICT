export interface BaseRequest {
    __token?: string
}

export interface BaseResponse {

}

export interface BaseConf {

}
/** 
 * needRole: string
 * needLogin: true | flase
*/
export interface BaseMessage {

}