import { ApiCall } from "tsrpc";
import { ReqUnjoinEvent, ResUnjoinEvent } from "../../shared/protocols/Event/PtlUnjoinEvent";

export default async function (call: ApiCall<ReqUnjoinEvent, ResUnjoinEvent>) {
    // TODO
}